// -----------------------------------------------------------------------------
// rMate Chart H5 License Key 
//
// Product Name : rMate Chart for HTML5 v6.0
// License Type : Enterprise  License
// Product No : xxxx-xxxx-xxxx-xxxx
// Authenticated server Info : undefined
// Expiration date : 
//
var rMateChartH5License = "xxxx";
// -----------------------------------------------------------------------------
