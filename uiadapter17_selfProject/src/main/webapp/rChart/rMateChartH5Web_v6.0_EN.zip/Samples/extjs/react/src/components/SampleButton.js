import React, {Component} from "react";
import {NavLink} from "react-router-dom";

export default class SampleButton extends Component{
	constructor(props){
		super(props);
	}
	
	render(){
		return (
			<NavLink to={this.props.sample.path}><div className="sample-button">{this.props.sample.name}</div></NavLink>
		);
	}
}
