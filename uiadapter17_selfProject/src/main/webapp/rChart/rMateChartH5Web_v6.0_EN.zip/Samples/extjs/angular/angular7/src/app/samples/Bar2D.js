this.layoutStr = '<rMateChart backgroundColor="#FFFFFF"  borderStyle="none">'
	+'<Options>'
		+'<Caption text="Rainfall"/>'
		+'<SubCaption text="( mm )" textAlign="right"/>'
		+'<Legend/>'
	+'</Options>'
	+'<Bar2DChart showDataTips="true">'
	   +'<horizontalAxis>'
		   +'<LinearAxis maximum="100"/>'
		+'</horizontalAxis>'
		+'<verticalAxis>'
			+'<CategoryAxis categoryField="Month"/>'
		+'</verticalAxis>'
		+'<series>'
			+'<Bar2DSeries labelPosition="inside" xField="Vancouver" displayName="Vancouver" showValueLabels="[6,7]" color="#ffffff" insideLabelYOffset="-2">'
				+'<showDataEffect>'
					+'<SeriesInterpolate/>'
				+'</showDataEffect>'
			+'</Bar2DSeries>'
		+'</series>'
	+'</Bar2DChart>'
+'</rMateChart>';

this.chartData = [{"Month":"Jan", "Vancouver":21},
	{"Month":"Feb", "Vancouver":29},
	{"Month":"Mar", "Vancouver":48},
	{"Month":"Apr", "Vancouver":38},
	{"Month":"May", "Vancouver":59},
	{"Month":"Jun", "Vancouver":77.2},
	{"Month":"Jul", "Vancouver":68},
	{"Month":"Aug", "Vancouver":58},
	{"Month":"Sep", "Vancouver":44},
	{"Month":"Oct", "Vancouver":23}
];
