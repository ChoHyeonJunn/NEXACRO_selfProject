/* eslint-disable */
samples = [
	{"path" : "/line", "js" : "Line2D", "name" : "Line2DChart"},
	{"path" : "/column", "js" : "Column2D", "name" : "Column2DChart"},
	{"path" : "/bar", "js" : "Bar2D", "name" : "Bar2DChart"},
	{"path" : "/labelField_func_column", "js" : "LabelField_Func_Column", "name" : "Column_User_Label"},
	{"path" : "/column_3d_custom_fill", "js" : "Column_3D_Custom_Fill", "name" : "Column_Custom_Fill"},
	{"path" : "/pattern_column_2d", "js" : "Pattern_Column_2D", "name" : "Pattern_Column_2D"}
];
