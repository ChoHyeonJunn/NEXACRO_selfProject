<template>
	<div>rMateChartH5 Vue SPA Sample</div>
</template>

<script>
</script>
