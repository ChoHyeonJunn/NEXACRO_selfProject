import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'Welcome',
    templateUrl: './Welcome.component.html',
    styleUrls: ['./Welcome.component.css']
})
export class Welcome implements OnInit{

    constructor(){
        
    }

    ngOnInit(){
    }
}
